package com.flixclusive.core.ui.common.navigation.navigator

interface SelectAvatarAction {
    fun openUserAvatarSelectScreen(selected: Int)
}
