package com.flixclusive.core.ui.common.navigation.navigator

interface StartHomeScreenAction {
    fun openHomeScreen()
}
