package com.flixclusive.core.ui.common.navigation.navigator

import com.flixclusive.model.provider.ProviderMetadata

interface TestProvidersAction {
    fun testProviders(providers: ArrayList<ProviderMetadata>)
}
