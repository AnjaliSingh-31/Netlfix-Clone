package com.flixclusive.core.ui.common.navigation.navargs

import com.flixclusive.model.provider.ProviderMetadata

data class ProviderMetadataNavArgs(
    val providerMetadata: ProviderMetadata
)
