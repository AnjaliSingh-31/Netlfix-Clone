package com.flixclusive.core.ui.common.navigation.navigator

interface SplashScreenNavigator :
    ExitAction,
    ViewNewAppUpdatesAction,
    StartHomeScreenAction,
    AddProfileAction,
    ChooseProfileAction
