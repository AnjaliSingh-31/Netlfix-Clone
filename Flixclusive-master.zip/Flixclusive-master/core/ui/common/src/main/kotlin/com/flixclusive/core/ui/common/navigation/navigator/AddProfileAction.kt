package com.flixclusive.core.ui.common.navigation.navigator

interface AddProfileAction {
    fun openAddProfileScreen(isInitializing: Boolean = false)
}
