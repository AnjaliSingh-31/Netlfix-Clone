package com.flixclusive.core.ui.common.navigation.navigator

interface GoBackAction {
    fun goBack()
}
