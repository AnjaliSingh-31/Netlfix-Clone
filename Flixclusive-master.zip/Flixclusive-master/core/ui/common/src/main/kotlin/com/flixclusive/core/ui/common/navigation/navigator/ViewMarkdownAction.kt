package com.flixclusive.core.ui.common.navigation.navigator

interface ViewMarkdownAction {
    fun openMarkdownScreen(
        title: String,
        description: String
    )
}
