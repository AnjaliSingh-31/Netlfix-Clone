package com.flixclusive.core.ui.common.navigation.navigator

interface ChooseProfileAction {
    fun openProfilesScreen(shouldPopBackStack: Boolean = false)
}
