package com.flixclusive.core.ui.common.navigation.navigator

interface ExitAction {
    fun onExitApplication()
}
