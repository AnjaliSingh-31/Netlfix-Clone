package com.flixclusive.core.ui.mobile.util

import androidx.compose.ui.unit.dp

object ComposeUtil {
    val DefaultScreenPaddingHorizontal = 8.dp
}