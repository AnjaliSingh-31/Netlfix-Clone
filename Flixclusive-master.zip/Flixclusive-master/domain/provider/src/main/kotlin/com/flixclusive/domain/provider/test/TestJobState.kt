package com.flixclusive.domain.provider.test

enum class TestJobState {
    PAUSED,
    RUNNING,
    IDLE;
}