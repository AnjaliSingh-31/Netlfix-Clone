![Flixclusive logo](https://i.imgur.com/tizcKbi.png)

<div>
  <table>
    <tr>
      <td>CI Build</td>
      <td><a href="https://github.com/flixclusiveorg/Flixclusive/actions/workflows/Build.yml"><img src="https://img.shields.io/github/actions/workflow/status/flixclusiveorg/Flixclusive/Build.yml?branch=master&event=push&style=for-the-badge&label=CI+Build" alt="CI"></a></td>
    </tr>
    <tr>
      <td>Quality Gate</td>
      <td><a href="https://sonarcloud.io/summary/overall?id=flixclusiveorg_Flixclusive"><img src="https://img.shields.io/sonar/quality_gate/flixclusiveorg_Flixclusive?server=https%3A%2F%2Fsonarcloud.io&style=for-the-badge" alt="Sonar quality gate"></a></td>
    </tr>
    <tr>
      <td>Pre-release</td>
      <td><a href="https://github.com/flixclusiveorg/Flixclusive/releases/PR-c62ada6"><img src="https://img.shields.io/github/downloads/flixclusiveorg/Flixclusive/PR-c62ada6/total?style=for-the-badge" alt="pre-release build"></a></td>
    </tr>
    <tr>
      <td>Stable</td>
      <td><a href="https://github.com/flixclusiveorg/Flixclusive/releases/latest"><img src="https://img.shields.io/github/downloads/flixclusiveorg/Flixclusive/latest/total?style=for-the-badge" alt="stable release"></a></td>
    </tr>
    <tr>
      <td>Discord</td>
      <td><a href="https://discord.gg/7yPSPveReu"><img src="https://img.shields.io/discord/1255770492049162240?label=discord&labelColor=7289da&color=2c2f33&style=for-the-badge" alt="Discord"></a></td>
    </tr>
  </table>
</div>

## Disclaimer
The app **DOES NOT** host and contain movies and tv shows streaming links!

## Roadmap
- Join the discord; its in there! 🥦

## Contributors
<a href="https://github.com/flixclusiveorg/Flixclusive/graphs/contributors">
  <img width="80" src="https://contrib.rocks/image?repo=flixclusiveorg/Flixclusive"  alt="Contributors"/>
</a>
